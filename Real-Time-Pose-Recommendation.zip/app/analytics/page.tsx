'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { ArrowLeft, Download } from 'lucide-react';

interface SessionRecord {
  id: string;
  exercise: string;
  duration: number;
  confidence: number;
  timestamp: Date;
}

const EXERCISES = ['Squat', 'Push-up', 'Lunge', 'Plank'];
const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

export default function AnalyticsPage() {
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [selectedExercise, setSelectedExercise] = useState('All');

  useEffect(() => {
    const savedSessions = localStorage.getItem('pose_sessions');
    if (savedSessions) {
      try {
        const parsed = JSON.parse(savedSessions);
        setSessions(parsed);
      } catch (err) {
        console.error('[v0] Failed to load sessions:', err);
      }
    }
  }, []);

  const filteredSessions =
    selectedExercise === 'All'
      ? sessions
      : sessions.filter((s) => s.exercise === selectedExercise);

  // Calculate statistics
  const stats = {
    totalSessions: sessions.length,
    avgConfidence:
      sessions.length > 0
        ? (
          sessions.reduce((sum, s) => sum + s.confidence, 0) / sessions.length * 100
        ).toFixed(1)
        : 0,
    totalDuration: sessions.reduce((sum, s) => sum + s.duration, 0),
    bestSession:
      sessions.length > 0
        ? Math.max(...sessions.map((s) => s.confidence)) * 100
        : 0,
  };

  // Exercise breakdown
  const exerciseStats = EXERCISES.map((exercise) => {
    const exerciseSessions = sessions.filter((s) => s.exercise === exercise);
    return {
      name: exercise,
      count: exerciseSessions.length,
      avgConfidence:
        exerciseSessions.length > 0
          ? (
            exerciseSessions.reduce((sum, s) => sum + s.confidence, 0) /
            exerciseSessions.length * 100
          ).toFixed(1)
          : 0,
    };
  });

  // Session history for chart
  const chartData = filteredSessions.map((session, idx) => ({
    id: idx,
    confidence: (session.confidence * 100).toFixed(0),
    duration: session.duration,
    exercise: session.exercise,
  }));

  const exportData = () => {
    const csv = [
      ['Exercise', 'Duration (s)', 'Confidence (%)', 'Date'],
      ...sessions.map((s) => [
        s.exercise,
        s.duration,
        (s.confidence * 100).toFixed(1),
        new Date(s.timestamp).toLocaleDateString(),
      ]),
    ]
      .map((row) => row.join(','))
      .join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pose-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Link href="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft size={16} />
                  Back to Detector
                </Button>
              </Link>
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-gray-900">
              Analytics & Progress
            </h1>
            <p className="text-gray-600 mt-1">
              Track your exercise performance over time
            </p>
          </div>

          {sessions.length > 0 && (
            <Button onClick={exportData} className="gap-2" variant="outline">
              <Download size={16} />
              Export CSV
            </Button>
          )}
        </div>

        {sessions.length === 0 ? (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <p className="text-lg text-gray-600 mb-4">
                No session data yet
              </p>
              <p className="text-sm text-gray-500 mb-6">
                Start a pose detection session to begin tracking your progress
              </p>
              <Link href="/">
                <Button>Go to Detector</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <p className="text-sm text-gray-600 mb-1">Total Sessions</p>
                  <p className="text-3xl font-bold text-blue-600">
                    {stats.totalSessions}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <p className="text-sm text-gray-600 mb-1">Avg Confidence</p>
                  <p className="text-3xl font-bold text-green-600">
                    {stats.avgConfidence}%
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <p className="text-sm text-gray-600 mb-1">Total Duration</p>
                  <p className="text-3xl font-bold text-purple-600">
                    {stats.totalDuration}s
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <p className="text-sm text-gray-600 mb-1">Best Session</p>
                  <p className="text-3xl font-bold text-orange-600">
                    {stats.bestSession.toFixed(0)}%
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="exercises">By Exercise</TabsTrigger>
                <TabsTrigger value="details">Session Details</TabsTrigger>
              </TabsList>

              {/* Overview Chart */}
              <TabsContent value="overview">
                <Card>
                  <CardHeader>
                    <CardTitle>Confidence Over Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {chartData.length > 0 ? (
                      <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="id" />
                          <YAxis domain={[0, 100]} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: '#fff',
                              border: '1px solid #ccc',
                            }}
                            formatter={(value) => `${value}%`}
                          />
                          <Legend />
                          <Line
                            type="monotone"
                            dataKey="confidence"
                            stroke="#3b82f6"
                            dot={false}
                            name="Confidence %"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    ) : (
                      <p className="text-center text-gray-500">No data</p>
                    )}
                  </CardContent>
                </Card>

                {/* Filter */}
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle className="text-base">Filter by Exercise</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {['All', ...EXERCISES].map((exercise) => (
                        <Button
                          key={exercise}
                          onClick={() => setSelectedExercise(exercise)}
                          variant={
                            selectedExercise === exercise ? 'default' : 'outline'
                          }
                          size="sm"
                        >
                          {exercise}
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Exercise Breakdown */}
              <TabsContent value="exercises">
                <Card>
                  <CardHeader>
                    <CardTitle>Exercise Performance</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={exerciseStats}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#fff',
                            border: '1px solid #ccc',
                          }}
                        />
                        <Legend />
                        <Bar
                          dataKey="avgConfidence"
                          fill="#3b82f6"
                          name="Avg Confidence %"
                        />
                      </BarChart>
                    </ResponsiveContainer>

                    {/* Exercise Statistics Table */}
                    <div className="mt-6">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2 font-semibold">
                              Exercise
                            </th>
                            <th className="text-center py-2 font-semibold">
                              Sessions
                            </th>
                            <th className="text-right py-2 font-semibold">
                              Avg Confidence
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {exerciseStats.map((stat) => (
                            <tr
                              key={stat.name}
                              className="border-b hover:bg-gray-50"
                            >
                              <td className="py-3 font-medium">{stat.name}</td>
                              <td className="text-center text-blue-600">
                                {stat.count}
                              </td>
                              <td className="text-right font-semibold text-green-600">
                                {stat.avgConfidence}%
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Details */}
              <TabsContent value="details">
                <Card>
                  <CardHeader>
                    <CardTitle>Session History</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2 font-semibold">
                              Exercise
                            </th>
                            <th className="text-center py-2 font-semibold">
                              Duration
                            </th>
                            <th className="text-right py-2 font-semibold">
                              Confidence
                            </th>
                            <th className="text-right py-2 font-semibold">
                              Date
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredSessions.map((session) => (
                            <tr
                              key={session.id}
                              className="border-b hover:bg-gray-50"
                            >
                              <td className="py-3 font-medium">
                                {session.exercise}
                              </td>
                              <td className="text-center">{session.duration}s</td>
                              <td className="text-right font-semibold text-green-600">
                                {(session.confidence * 100).toFixed(1)}%
                              </td>
                              <td className="text-right text-gray-500">
                                {new Date(session.timestamp).toLocaleDateString()}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </main>
  );
}
