import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

function getSupabaseAdminClient() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !supabaseKey) {
    throw new Error('Missing Supabase credentials');
  }

  return createClient(supabaseUrl, supabaseKey);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, sessionData, frameData, sessionStats } = body;
    const supabase = getSupabaseAdminClient();

    if (action === 'create') {
      // Create a new exercise session
      const { data, error } = await supabase
        .from('exercise_sessions')
        .insert([
          {
            exercise_id: sessionData.exerciseId,
            user_id: sessionData.userId,
            started_at: new Date(),
          },
        ])
        .select();

      if (error) {
        return NextResponse.json(
          { success: false, error: error.message },
          { status: 400 }
        );
      }

      return NextResponse.json({
        success: true,
        sessionId: data?.[0]?.id,
      });
    }

    if (action === 'saveFrame') {
      // Save a pose frame
      const { error } = await supabase.from('pose_frames').insert([
        {
          session_id: frameData.sessionId,
          frame_number: frameData.frameNumber,
          timestamp: new Date(),
          keypoints: frameData.keypoints,
          joint_angles: frameData.jointAngles,
          form_feedback: frameData.formFeedback,
          form_confidence: frameData.formConfidence,
          body_part_confidence: frameData.bodyPartConfidence,
        },
      ]);

      if (error) {
        return NextResponse.json(
          { success: false, error: error.message },
          { status: 400 }
        );
      }

      return NextResponse.json({ success: true });
    }

    if (action === 'updateSession') {
      // Update session stats
      const { error } = await supabase
        .from('exercise_sessions')
        .update({
          ended_at: new Date(),
          duration_seconds: sessionStats.duration,
          average_form_confidence: sessionStats.averageConfidence,
        })
        .eq('id', sessionStats.sessionId);

      if (error) {
        return NextResponse.json(
          { success: false, error: error.message },
          { status: 400 }
        );
      }

      return NextResponse.json({ success: true });
    }

    return NextResponse.json(
      { success: false, error: 'Unknown action' },
      { status: 400 }
    );
  } catch (error) {
    console.error('[v0] Session API error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    const supabase = getSupabaseAdminClient();

    if (action === 'exercises') {
      const { data, error } = await supabase
        .from('exercises')
        .select('*');

      if (error) {
        return NextResponse.json(
          { success: false, error: error.message },
          { status: 400 }
        );
      }

      return NextResponse.json({
        success: true,
        exercises: data,
      });
    }

    return NextResponse.json(
      { success: false, error: 'Unknown action' },
      { status: 400 }
    );
  } catch (error) {
    console.error('[v0] Session API error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}
