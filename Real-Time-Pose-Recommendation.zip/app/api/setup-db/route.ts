import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase environment variables');
}

const supabase = createClient(supabaseUrl, supabaseKey);

export async function POST() {
  try {
    console.log('Starting database setup...');

    // Create exercises table first with data
    const exercises = [
      {
        name: 'Squat',
        description: 'Lower body exercise targeting quads, glutes, and hamstrings',
        category: 'Lower Body',
        difficulty_level: 'Beginner',
        form_rules: {
          target_angles: {
            left_knee: { min: 60, max: 110 },
            right_knee: { min: 60, max: 110 },
            left_hip: { min: 70, max: 100 },
            right_hip: { min: 70, max: 100 },
            back_angle: { min: 15, max: 45 }
          },
          critical_points: ['knee_alignment', 'back_straight', 'weight_centered']
        }
      },
      {
        name: 'Push-up',
        description: 'Upper body exercise targeting chest, shoulders, and triceps',
        category: 'Upper Body',
        difficulty_level: 'Beginner',
        form_rules: {
          target_angles: {
            left_elbow: { min: 45, max: 90 },
            right_elbow: { min: 45, max: 90 },
            shoulder_angle: { min: 60, max: 90 }
          },
          critical_points: ['body_straight', 'elbows_tracking', 'shoulders_engaged']
        }
      },
      {
        name: 'Lunge',
        description: 'Lower body exercise for single leg strength and balance',
        category: 'Lower Body',
        difficulty_level: 'Intermediate',
        form_rules: {
          target_angles: {
            front_knee: { min: 70, max: 110 },
            back_knee: { min: 30, max: 90 },
            torso_angle: { min: 10, max: 30 }
          },
          critical_points: ['front_knee_aligned', 'back_knee_low', 'upright_torso']
        }
      },
      {
        name: 'Plank',
        description: 'Core stability exercise',
        category: 'Core',
        difficulty_level: 'Beginner',
        form_rules: {
          target_angles: {
            body_angle: { min: 0, max: 10 }
          },
          critical_points: ['straight_body', 'engaged_core', 'neutral_neck']
        }
      }
    ];

    // Try to insert exercises
    const { data: existingExercises } = await supabase
      .from('exercises')
      .select('id')
      .limit(1);

    if (!existingExercises || existingExercises.length === 0) {
      const { error: insertError, data } = await supabase
        .from('exercises')
        .insert(exercises)
        .select();

      if (insertError) {
        console.warn('Insert error:', insertError);
        return NextResponse.json(
          { 
            success: false, 
            message: 'Database might not be initialized yet',
            error: insertError.message 
          },
          { status: 500 }
        );
      }

      console.log('Inserted exercises:', data);
    }

    return NextResponse.json({
      success: true,
      message: 'Database setup complete'
    });
  } catch (error) {
    console.error('Setup error:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      },
      { status: 500 }
    );
  }
}
