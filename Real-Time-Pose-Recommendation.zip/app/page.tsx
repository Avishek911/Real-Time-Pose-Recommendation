'use client';

import { useState } from 'react';
import Link from 'next/link';
import PoseDetector from '@/components/pose-detector';
import ExerciseSelector from '@/components/exercise-selector';
import SessionTracker from '@/components/session-tracker';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { BarChart3 } from 'lucide-react';

export default function Home() {
  const [selectedExercise, setSelectedExercise] = useState('Squat');
  const [sessionStats, setSessionStats] = useState({
    confidence: 0,
    feedbackCount: 0,
    isGoodForm: false,
    startTime: Date.now(),
    frameCount: 0,
  });

  const handleSessionUpdate = (data: {
    confidence: number;
    feedbackCount: number;
    isGoodForm: boolean;
  }) => {
    setSessionStats((prev) => ({
      ...prev,
      ...data,
      frameCount: prev.frameCount + 1,
    }));
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 mb-2">
              Real-Time Pose Recommendation
            </h1>
            <p className="text-gray-600">
              Get instant feedback on your exercise form using AI-powered pose detection
            </p>
          </div>
          <Link href="/analytics">
            <Button variant="outline" className="gap-2">
              <BarChart3 size={16} />
              Analytics
            </Button>
          </Link>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Exercise Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Select Exercise</CardTitle>
              </CardHeader>
              <CardContent>
                <ExerciseSelector
                  selectedExercise={selectedExercise}
                  onSelectExercise={setSelectedExercise}
                />
              </CardContent>
            </Card>

            {/* Pose Detector */}
            <PoseDetector
              exerciseName={selectedExercise}
              onSessionUpdate={handleSessionUpdate}
            />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Session Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Average Confidence</p>
                  <p className="text-3xl font-bold text-green-600">
                    {(sessionStats.confidence * 100).toFixed(0)}%
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Active Issues</p>
                  <p className="text-3xl font-bold text-orange-600">
                    {sessionStats.feedbackCount}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Frames Processed</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {sessionStats.frameCount.toLocaleString()}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Session History */}
            <SessionTracker />

            {/* Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Tips for {selectedExercise}</CardTitle>
              </CardHeader>
              <CardContent>
                <ExerciseTips exerciseName={selectedExercise} />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}

function ExerciseTips({ exerciseName }: { exerciseName: string }) {
  const tips: { [key: string]: string[] } = {
    Squat: [
      'Keep feet shoulder-width apart',
      'Chest up, weight in heels',
      'Lower until thighs are parallel',
      'Maintain neutral spine',
      'Drive through heels to stand',
    ],
    'Push-up': [
      'Hands slightly wider than shoulders',
      'Body in straight line head to heels',
      'Lower until chest nearly touches floor',
      'Keep elbows 45° from body',
      'Engage core throughout',
    ],
    Lunge: [
      'Step forward with control',
      'Front knee over ankle',
      'Lower back knee toward ground',
      'Keep torso upright',
      'Push off front heel to stand',
    ],
    Plank: [
      'Hands under shoulders',
      'Body perfectly straight',
      'Engage your core',
      'Hold steady breathing',
      'Avoid sagging or hiking hips',
    ],
  };

  return (
    <ul className="space-y-2">
      {(tips[exerciseName] || []).map((tip, idx) => (
        <li key={idx} className="flex items-start gap-2 text-sm">
          <span className="text-green-600 font-bold mt-0.5">✓</span>
          <span className="text-gray-700">{tip}</span>
        </li>
      ))}
    </ul>
  );
}
