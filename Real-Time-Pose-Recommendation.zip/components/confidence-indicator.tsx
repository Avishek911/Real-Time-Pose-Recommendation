'use client';

import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ConfidenceIndicatorProps {
  confidence: number;
  bodyPartConfidence: { [key: string]: number };
  isGoodForm: boolean;
}

export default function ConfidenceIndicator({
  confidence,
  bodyPartConfidence,
  isGoodForm,
}: ConfidenceIndicatorProps) {
  // Sort body parts by confidence
  const sortedParts = Object.entries(bodyPartConfidence)
    .map(([part, conf]) => ({
      part: formatPartName(part),
      confidence: conf,
    }))
    .sort((a, b) => a.confidence - b.confidence)
    .slice(0, 6); // Show top 6 body parts

  const getConfidenceColor = (conf: number): string => {
    if (conf >= 0.8) return 'bg-green-500';
    if (conf >= 0.6) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getConfidenceLabel = (conf: number): string => {
    if (conf >= 0.8) return 'Excellent';
    if (conf >= 0.6) return 'Good';
    if (conf >= 0.4) return 'Fair';
    return 'Poor';
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">
          Form Quality: {getConfidenceLabel(confidence)}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall Confidence */}
        <div>
          <div className="flex justify-between mb-2">
            <span className="text-sm font-medium">Overall Confidence</span>
            <span className="text-sm font-semibold">
              {(confidence * 100).toFixed(0)}%
            </span>
          </div>
          <Progress
            value={confidence * 100}
            className="h-2"
          />
          <div className={`text-xs mt-1 font-semibold ${
            isGoodForm ? 'text-green-600' : 'text-orange-600'
          }`}>
            {isGoodForm ? '✓ Good Form' : '⚠ Form needs adjustment'}
          </div>
        </div>

        {/* Body Part Details */}
        <div className="space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-600">
            Body Part Confidence
          </p>
          <div className="grid grid-cols-2 gap-3">
            {sortedParts.map((part) => (
              <div
                key={part.part}
                className="bg-gray-50 p-2 rounded-md border border-gray-200"
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-medium">{part.part}</span>
                  <span className="text-xs font-semibold">
                    {(part.confidence * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${getConfidenceColor(
                      part.confidence
                    )} transition-all duration-300`}
                    style={{ width: `${part.confidence * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Confidence Legend */}
        <div className="grid grid-cols-3 gap-2 pt-2 border-t">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-xs text-gray-600">Excellent (80%+)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
            <span className="text-xs text-gray-600">Good (60-80%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-red-500 rounded-full"></div>
            <span className="text-xs text-gray-600">Poor (&lt;60%)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function formatPartName(part: string): string {
  return part
    .split('_')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ')
    .replace('_', ' ');
}
