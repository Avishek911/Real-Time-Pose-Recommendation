'use client';

import { Button } from '@/components/ui/button';

const EXERCISES = [
  {
    id: 'squat',
    name: 'Squat',
    icon: '🏋️',
    description: 'Lower body strength',
    difficulty: 'Beginner',
  },
  {
    id: 'pushup',
    name: 'Push-up',
    icon: '💪',
    description: 'Upper body strength',
    difficulty: 'Beginner',
  },
  {
    id: 'lunge',
    name: 'Lunge',
    icon: '🦵',
    description: 'Single leg balance',
    difficulty: 'Intermediate',
  },
  {
    id: 'plank',
    name: 'Plank',
    icon: '📏',
    description: 'Core stability',
    difficulty: 'Beginner',
  },
];

interface ExerciseSelectorProps {
  selectedExercise: string;
  onSelectExercise: (exercise: string) => void;
}

export default function ExerciseSelector({
  selectedExercise,
  onSelectExercise,
}: ExerciseSelectorProps) {
  return (
    <div className="grid grid-cols-2 gap-3">
      {EXERCISES.map((exercise) => (
        <Button
          key={exercise.id}
          onClick={() => onSelectExercise(exercise.name)}
          variant={selectedExercise === exercise.name ? 'default' : 'outline'}
          className="h-auto flex flex-col items-center justify-center py-4 px-3"
        >
          <span className="text-2xl mb-1">{exercise.icon}</span>
          <span className="font-semibold text-sm">{exercise.name}</span>
          <span className="text-xs text-gray-500">{exercise.description}</span>
        </Button>
      ))}
    </div>
  );
}
