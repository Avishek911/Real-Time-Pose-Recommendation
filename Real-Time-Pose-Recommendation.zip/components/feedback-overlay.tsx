'use client';

import { FormFeedback } from '@/lib/form-analyzer';
import { AlertCircle, CheckCircle2, Info } from 'lucide-react';

interface FeedbackOverlayProps {
  feedback: FormFeedback[];
  isGoodForm: boolean;
}

export default function FeedbackOverlay({
  feedback,
  isGoodForm,
}: FeedbackOverlayProps) {
  // Group feedback by severity
  const criticalFeedback = feedback.filter((f) => f.severity === 'critical');
  const warningFeedback = feedback.filter((f) => f.severity === 'warning');
  const infoFeedback = feedback.filter((f) => f.severity === 'info');

  // Display only top 3 most relevant issues
  const displayFeedback = [
    ...criticalFeedback.slice(0, 2),
    ...warningFeedback.slice(0, 1),
  ];

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col p-4">
      {/* Top Section - Good Form Indicator */}
      <div className="flex justify-center mb-4">
        {isGoodForm ? (
          <div className="bg-green-500 bg-opacity-80 text-white px-6 py-3 rounded-full flex items-center gap-2 font-semibold animate-pulse">
            <CheckCircle2 size={20} />
            <span>Perfect Form!</span>
          </div>
        ) : null}
      </div>

      {/* Bottom Section - Feedback Cards */}
      <div className="mt-auto space-y-2 max-w-xs">
        {displayFeedback.length > 0 ? (
          displayFeedback.map((item, idx) => (
            <FeedbackCard key={idx} feedback={item} />
          ))
        ) : (
          <div className="bg-blue-500 bg-opacity-80 text-white px-4 py-3 rounded-lg flex items-center gap-2 text-sm">
            <Info size={16} />
            <span>Good positioning. Keep it steady!</span>
          </div>
        )}

        {/* Issue Count Badge */}
        {feedback.length > displayFeedback.length && (
          <div className="bg-orange-500 bg-opacity-80 text-white px-4 py-2 rounded-lg text-xs text-center font-semibold">
            +{feedback.length - displayFeedback.length} more issues
          </div>
        )}
      </div>
    </div>
  );
}

function FeedbackCard({ feedback }: { feedback: FormFeedback }) {
  const getIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertCircle size={16} />;
      case 'warning':
        return <AlertCircle size={16} />;
      default:
        return <Info size={16} />;
    }
  };

  const getStyles = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-600 bg-opacity-85 text-white';
      case 'warning':
        return 'bg-yellow-600 bg-opacity-85 text-white';
      default:
        return 'bg-blue-600 bg-opacity-85 text-white';
    }
  };

  return (
    <div className={`${getStyles(feedback.severity)} px-4 py-3 rounded-lg text-sm`}>
      <div className="flex items-start gap-2">
        <div className="flex-shrink-0 mt-0.5">{getIcon(feedback.severity)}</div>
        <div className="flex-1">
          <p className="font-semibold text-xs uppercase tracking-wide mb-1">
            {feedback.bodyPart}
          </p>
          <p className="text-sm leading-snug">{feedback.issue}</p>
          <div className="mt-2 bg-black bg-opacity-30 rounded px-2 py-1 text-xs">
            Confidence: {(feedback.confidence * 100).toFixed(0)}%
          </div>
        </div>
      </div>
    </div>
  );
}
