'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import {
  initializePoseDetector,
  detectPose,
  drawPose,
  calculateJointAngles,
  PoseData,
} from '@/lib/pose-detector';
import {
  analyzeFormForExercise,
  filterFeedbackByFrequency,
  FormAnalysisResult,
} from '@/lib/form-analyzer';
import { playAudioCue, speakFeedback, initializeAudio } from '@/lib/audio-feedback';
import FeedbackOverlay from './feedback-overlay';
import ConfidenceIndicator from './confidence-indicator';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface PoseDetectorProps {
  exerciseName: string;
  onSessionUpdate?: (data: {
    confidence: number;
    feedbackCount: number;
    isGoodForm: boolean;
  }) => void;
}

export default function PoseDetector({
  exerciseName,
  onSessionUpdate,
}: PoseDetectorProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const animationIdRef = useRef<number>();
  const lastAnalysisTimeRef = useRef<number>(0);
  const previousAnglesRef = useRef<Record<string, number>>({});
  const fpsCounterRef = useRef<{ lastTime: number; frames: number }>({
    lastTime: Date.now(),
    frames: 0,
  });

  const [isInitialized, setIsInitialized] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formAnalysis, setFormAnalysis] = useState<FormAnalysisResult | null>(null);
  const [frameCount, setFrameCount] = useState(0);
  const [fps, setFps] = useState(0);
  const sessionStartTimeRef = useRef<number>(0);
  const sessionConfidenceRef = useRef<number[]>([]);

  // Initialize pose detector and audio
  useEffect(() => {
    const init = async () => {
      try {
        initializeAudio();
        await initializePoseDetector();
        setIsInitialized(true);
      } catch (err) {
        setError(
          err instanceof Error ? err.message : 'Failed to initialize pose detector'
        );
      }
    };

    init();
  }, []);

  // Start video stream
  const startDetection = useCallback(async () => {
    if (!videoRef.current) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user',
        },
      });

      videoRef.current.srcObject = stream;
      setIsRunning(true);
      setError(null);
      setFrameCount(0);
      
      // Initialize session tracking
      sessionStartTimeRef.current = Date.now();
      sessionConfidenceRef.current = [];

      // Wait for video to load
      videoRef.current.onloadedmetadata = () => {
        videoRef.current?.play().catch((err) => {
          console.error('[v0] Video play error:', err);
          setError('Could not start video');
        });
      };
    } catch (err) {
      console.error('[v0] Camera error:', err);
      setError('Camera access denied. Please allow camera permissions.');
      setIsRunning(false);
    }
  }, []);

  // Stop detection
  const stopDetection = useCallback(() => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach((track) => track.stop());
    }

    if (animationIdRef.current) {
      cancelAnimationFrame(animationIdRef.current);
    }

    // Save session to localStorage
    if (sessionStartTimeRef.current > 0 && sessionConfidenceRef.current.length > 0) {
      const duration = Math.round((Date.now() - sessionStartTimeRef.current) / 1000);
      const avgConfidence = sessionConfidenceRef.current.reduce((a, b) => a + b, 0) / sessionConfidenceRef.current.length;
      
      const session = {
        id: `session_${Date.now()}`,
        exercise: exerciseName,
        duration,
        confidence: avgConfidence,
        timestamp: new Date(),
      };

      try {
        const existingSessions = localStorage.getItem('pose_sessions');
        const sessions = existingSessions ? JSON.parse(existingSessions) : [];
        sessions.push(session);
        localStorage.setItem('pose_sessions', JSON.stringify(sessions));
        console.log('[v0] Session saved:', session);
        
        // Dispatch custom event to update session tracker
        window.dispatchEvent(new Event('pose-session-saved'));
      } catch (err) {
        console.error('[v0] Failed to save session:', err);
      }
    }

    setIsRunning(false);
  }, [exerciseName]);

  // Main detection loop
  useEffect(() => {
    if (!isRunning || !videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;

    const detectFrame = (timestamp: number) => {
      if (video.readyState !== video.HAVE_ENOUGH_DATA) {
        animationIdRef.current = requestAnimationFrame(detectFrame);
        return;
      }

      // Set canvas size to match video
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      // Detect pose
      const poseData = detectPose(video, timestamp);

      if (poseData) {
        const angles = calculateJointAngles(poseData.keypoints);

        // Analyze form every frame but limit analysis calls
        const analysisTime = Date.now();
        if (analysisTime - lastAnalysisTimeRef.current > 100) {
          // Analyze every ~100ms
          const analysis = analyzeFormForExercise(
            exerciseName,
            angles,
            poseData.keypoints,
            previousAnglesRef.current
          );

          // Filter duplicates and low confidence feedback
          const filteredFeedback = filterFeedbackByFrequency(analysis.feedback);

          setFormAnalysis({
            ...analysis,
            feedback: filteredFeedback,
          });

          // Play audio feedback for critical issues
          const criticalIssues = filteredFeedback.filter(
            (f) => f.severity === 'critical'
          );
          if (criticalIssues.length > 0) {
            playAudioCue('critical');
            speakFeedback(criticalIssues);
          } else if (filteredFeedback.length > 0) {
            playAudioCue('warning');
          } else {
            playAudioCue('success');
          }

          lastAnalysisTimeRef.current = analysisTime;
          previousAnglesRef.current = angles;
          
          // Track confidence for session
          sessionConfidenceRef.current.push(analysis.overallConfidence);

          // Notify parent component
          if (onSessionUpdate) {
            onSessionUpdate({
              confidence: analysis.overallConfidence,
              feedbackCount: filteredFeedback.length,
              isGoodForm: analysis.isGoodForm,
            });
          }
        }

        // Draw pose visualization
        drawPose(
          canvas,
          poseData,
          formAnalysis?.feedback,
          poseData.confidence
        );

        // Update frame counter
        setFrameCount((prev) => prev + 1);

        // Update FPS counter
        const fpsTime = Date.now();
        if (fpsTime - fpsCounterRef.current.lastTime >= 1000) {
          setFps(fpsCounterRef.current.frames);
          fpsCounterRef.current = { lastTime: fpsTime, frames: 0 };
        } else {
          fpsCounterRef.current.frames++;
        }
      } else {
        // Clear canvas if no pose detected
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          ctx.fillStyle = 'rgba(255, 100, 100, 0.5)';
          ctx.font = 'bold 20px Arial';
          ctx.fillText('Adjusting camera... ', 20, 40);
        }
      }

      animationIdRef.current = requestAnimationFrame(detectFrame);
    };

    animationIdRef.current = requestAnimationFrame(detectFrame);

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
    };
  }, [isRunning, exerciseName, onSessionUpdate]);

  return (
    <div ref={containerRef} className="w-full space-y-4">
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {/* Video and Canvas Container */}
            <div className="relative w-full bg-black rounded-lg overflow-hidden aspect-video">
              <video
                ref={videoRef}
                className="absolute inset-0 w-full h-full object-cover"
                playsInline
              />
              <canvas
                ref={canvasRef}
                className="absolute inset-0 w-full h-full"
              />

              {/* Overlay UI */}
              {formAnalysis && (
                <FeedbackOverlay
                  feedback={formAnalysis.feedback}
                  isGoodForm={formAnalysis.isGoodForm}
                />
              )}

              {/* Top Right Stats */}
              <div className="absolute top-4 right-4 space-y-2">
                <div className="bg-black bg-opacity-70 text-white px-3 py-2 rounded text-sm">
                  FPS: {fps}
                </div>
                <div className="bg-black bg-opacity-70 text-white px-3 py-2 rounded text-sm">
                  Frames: {frameCount}
                </div>
              </div>

              {/* Error or Loading State */}
              {error && (
                <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-75">
                  <div className="text-white text-center">
                    <p className="text-lg font-semibold mb-2">Error</p>
                    <p className="text-sm">{error}</p>
                  </div>
                </div>
              )}

              {!isRunning && !error && (
                <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
                  <div className="text-white text-center">
                    <p className="text-lg font-semibold mb-4">Ready to detect pose</p>
                    <p className="text-sm mb-4">Click start to begin</p>
                  </div>
                </div>
              )}
            </div>

            {/* Confidence Indicator */}
            {formAnalysis && (
              <ConfidenceIndicator
                confidence={formAnalysis.overallConfidence}
                bodyPartConfidence={formAnalysis.bodyPartConfidence}
                isGoodForm={formAnalysis.isGoodForm}
              />
            )}

            {/* Control Buttons */}
            <div className="flex gap-2 justify-center">
              <Button
                onClick={startDetection}
                disabled={!isInitialized || isRunning}
                className="bg-green-600 hover:bg-green-700"
              >
                {isRunning ? 'Running...' : 'Start Detection'}
              </Button>
              <Button
                onClick={stopDetection}
                disabled={!isRunning}
                variant="destructive"
              >
                Stop Detection
              </Button>
            </div>

            {/* Status */}
            {!isInitialized && (
              <p className="text-center text-sm text-gray-600">
                Initializing pose detector...
              </p>
            )}
            {isInitialized && !isRunning && !error && (
              <p className="text-center text-sm text-gray-600">
                Ready. Camera access required.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
