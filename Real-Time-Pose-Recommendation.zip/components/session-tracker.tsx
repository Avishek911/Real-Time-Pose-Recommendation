'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart3, TrashIcon } from 'lucide-react';

interface SessionRecord {
  id: string;
  exercise: string;
  duration: number;
  confidence: number;
  timestamp: Date;
}

export default function SessionTracker() {
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadSessions = () => {
    const savedSessions = localStorage.getItem('pose_sessions');
    if (savedSessions) {
      try {
        const parsed = JSON.parse(savedSessions);
        setSessions(parsed);
      } catch (err) {
        console.error('[v0] Failed to load sessions:', err);
      }
    } else {
      setSessions([]);
    }
  };

  useEffect(() => {
    // Load sessions from localStorage
    loadSessions();
    setIsLoading(false);

    // Listen for storage changes (from other tabs or same component)
    const handleStorageChange = () => {
      loadSessions();
    };

    window.addEventListener('storage', handleStorageChange);
    
    // Also set up a custom event listener for updates from the pose detector
    const handleSessionsUpdate = () => {
      loadSessions();
    };

    window.addEventListener('pose-session-saved', handleSessionsUpdate);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('pose-session-saved', handleSessionsUpdate);
    };
  }, []);

  const clearHistory = () => {
    setSessions([]);
    localStorage.removeItem('pose_sessions');
  };

  const avgConfidence =
    sessions.length > 0
      ? (
        sessions.reduce((sum, s) => sum + s.confidence, 0) / sessions.length
      ).toFixed(0)
      : 0;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <BarChart3 size={20} />
            Session History
          </CardTitle>
          {sessions.length > 0 && (
            <Button
              onClick={clearHistory}
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
            >
              <TrashIcon size={16} />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading ? (
          <p className="text-sm text-gray-500">Loading sessions...</p>
        ) : sessions.length === 0 ? (
          <div className="text-center py-6">
            <p className="text-sm text-gray-500 mb-2">No sessions yet</p>
            <p className="text-xs text-gray-400">
              Start a detection session to track progress
            </p>
          </div>
        ) : (
          <>
            {/* Stats Summary */}
            <div className="grid grid-cols-2 gap-2 mb-2 p-2 bg-gray-50 rounded">
              <div>
                <p className="text-xs text-gray-600">Total Sessions</p>
                <p className="text-lg font-bold text-blue-600">{sessions.length}</p>
              </div>
              <div>
                <p className="text-xs text-gray-600">Avg Confidence</p>
                <p className="text-lg font-bold text-green-600">{avgConfidence}%</p>
              </div>
            </div>

            {/* Sessions List */}
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {sessions.map((session) => (
                <div
                  key={session.id}
                  className="flex justify-between items-center p-2 bg-gray-50 rounded text-sm border border-gray-200"
                >
                  <div>
                    <p className="font-medium text-gray-900">{session.exercise}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(session.timestamp).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-green-600">
                      {(session.confidence * 100).toFixed(0)}%
                    </p>
                    <p className="text-xs text-gray-500">
                      {session.duration}s
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
