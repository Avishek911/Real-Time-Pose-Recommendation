import { FormFeedback } from './form-analyzer';

export interface AudioConfig {
  volume: number;
  enabled: boolean;
  rate: number;
  pitch: number;
}

let synthesisSupported = false;
let lastSpeechTime = 0;
let audioContext: AudioContext | null = null;
const SPEECH_DEBOUNCE_MS = 2000; // Don't repeat same feedback too often

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  
  if (!audioContext) {
    try {
      const AudioContextClass =
        (window as any).AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioContext = new AudioContextClass();
      }
    } catch (error) {
      console.error('[v0] Failed to create audio context:', error);
      return null;
    }
  }

  return audioContext;
}

export function initializeAudio(): AudioConfig {
  synthesisSupported =
    'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;

  if (synthesisSupported) {
    console.log('[v0] Web Speech API available');
  }

  return {
    volume: 1,
    enabled: true,
    rate: 1,
    pitch: 1,
  };
}

export function playAudioCue(type: 'success' | 'warning' | 'critical'): void {
  // Use Web Audio API for simple beeps
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    const now = ctx.currentTime;

    switch (type) {
      case 'success':
        // High pitched success beep
        oscillator.frequency.setValueAtTime(800, now);
        oscillator.frequency.setValueAtTime(600, now + 0.1);
        gainNode.gain.setValueAtTime(0.3, now);
        gainNode.gain.setValueAtTime(0, now + 0.1);
        oscillator.start(now);
        oscillator.stop(now + 0.1);
        break;

      case 'warning':
        // Medium pitched warning
        oscillator.frequency.setValueAtTime(600, now);
        oscillator.frequency.setValueAtTime(400, now + 0.15);
        gainNode.gain.setValueAtTime(0.2, now);
        gainNode.gain.setValueAtTime(0, now + 0.15);
        oscillator.start(now);
        oscillator.stop(now + 0.15);
        break;

      case 'critical':
        // Low pitched critical alert (double beep)
        oscillator.frequency.setValueAtTime(300, now);
        oscillator.frequency.setValueAtTime(250, now + 0.1);
        gainNode.gain.setValueAtTime(0.3, now);
        gainNode.gain.setValueAtTime(0, now + 0.1);
        oscillator.start(now);
        oscillator.stop(now + 0.1);

        // Create second oscillator for second beep
        const oscillator2 = ctx.createOscillator();
        oscillator2.connect(gainNode);
        oscillator2.frequency.setValueAtTime(300, now + 0.15);
        oscillator2.frequency.setValueAtTime(250, now + 0.25);
        oscillator2.start(now + 0.15);
        oscillator2.stop(now + 0.25);
        break;
    }
  } catch (error) {
    console.error('[v0] Audio playback error:', error);
  }
}

export function speakFeedback(feedback: FormFeedback[]): void {
  if (!synthesisSupported || !feedback.length) return;

  const now = Date.now();
  if (now - lastSpeechTime < SPEECH_DEBOUNCE_MS) {
    return; // Too soon, don't speak
  }

  try {
    window.speechSynthesis.cancel(); // Cancel any ongoing speech

    // Create a concise message from critical feedback
    const criticalIssues = feedback
      .filter((f) => f.severity === 'critical')
      .slice(0, 2); // Max 2 issues per message

    if (criticalIssues.length === 0) return;

    const messages = criticalIssues.map((f) => {
      // Shorten the message for speech
      if (f.issue.includes('too narrow')) return `${f.bodyPart} too narrow`;
      if (f.issue.includes('too wide')) return `${f.bodyPart} too wide`;
      if (f.issue.includes('inward')) return `${f.bodyPart} caving in`;
      if (f.issue.includes('straight'))
        return 'Keep body straight';
      if (f.issue.includes('alignment')) return 'Fix alignment';
      return f.issue;
    });

    const utterance = new SpeechSynthesisUtterance(messages.join('. '));
    utterance.rate = 1.5; // Faster speech
    utterance.pitch = 1;
    utterance.volume = 0.7;

    window.speechSynthesis.speak(utterance);
    lastSpeechTime = now;
  } catch (error) {
    console.error('[v0] Speech synthesis error:', error);
  }
}

export function muteAudio(): void {
  if (synthesisSupported) {
    window.speechSynthesis.cancel();
  }
}

export function getAudioSupported(): boolean {
  return synthesisSupported;
}
