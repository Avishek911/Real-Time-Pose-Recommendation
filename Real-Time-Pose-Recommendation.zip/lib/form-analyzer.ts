import {
  JointAngles,
  FormFeedback,
  Keypoint,
  calculateAngle,
  LANDMARKS,
} from './pose-detector';

export interface ExerciseFormRules {
  target_angles?: {
    [key: string]: { min: number; max: number };
  };
  critical_points?: string[];
}

export interface FormAnalysisResult {
  feedback: FormFeedback[];
  overallConfidence: number;
  bodyPartConfidence: { [key: string]: number };
  isGoodForm: boolean;
}

export const EXERCISE_RULES: {
  [key: string]: ExerciseFormRules;
} = {
  Squat: {
    target_angles: {
      left_knee: { min: 60, max: 110 },
      right_knee: { min: 60, max: 110 },
      left_hip: { min: 70, max: 100 },
      right_hip: { min: 70, max: 100 },
      body_tilt: { min: -15, max: 15 },
    },
    critical_points: ['knee_alignment', 'back_straight', 'weight_centered'],
  },
  'Push-up': {
    target_angles: {
      left_elbow: { min: 45, max: 90 },
      right_elbow: { min: 45, max: 90 },
      body_tilt: { min: -10, max: 10 },
    },
    critical_points: ['body_straight', 'elbows_tracking', 'shoulders_engaged'],
  },
  Lunge: {
    target_angles: {
      front_knee: { min: 70, max: 110 },
      back_knee: { min: 30, max: 90 },
      body_tilt: { min: -20, max: 20 },
    },
    critical_points: ['front_knee_aligned', 'back_knee_low', 'upright_torso'],
  },
  Plank: {
    target_angles: {
      body_tilt: { min: -5, max: 5 },
    },
    critical_points: ['straight_body', 'engaged_core', 'neutral_neck'],
  },
};

export function analyzeFormForExercise(
  exerciseName: string,
  angles: JointAngles,
  keypoints: Keypoint[],
  previousAngles?: JointAngles
): FormAnalysisResult {
  const rules = EXERCISE_RULES[exerciseName];
  if (!rules) {
    return {
      feedback: [],
      overallConfidence: 0,
      bodyPartConfidence: {},
      isGoodForm: false,
    };
  }

  const feedback: FormFeedback[] = [];
  const bodyPartConfidence: { [key: string]: number } = {};
  let totalScore = 0;
  let totalAngles = 0;

  // Analyze joint angles
  if (rules.target_angles) {
    Object.entries(rules.target_angles).forEach(([joint, range]) => {
      const angle = angles[joint];

      if (angle === undefined) return;

      const isInRange = angle >= range.min && angle <= range.max;
      const confidence = calculateAngleConfidence(angle, range.min, range.max);

      bodyPartConfidence[joint] = confidence;
      totalScore += confidence;
      totalAngles++;

      if (!isInRange) {
        if (angle < range.min) {
          feedback.push({
            bodyPart: formatJointName(joint),
            issue: `Angle too narrow (${angle.toFixed(0)}°). Aim for ${range.min}-${range.max}°`,
            severity: confidence < 0.4 ? 'critical' : 'warning',
            confidence,
          });
        } else {
          feedback.push({
            bodyPart: formatJointName(joint),
            issue: `Angle too wide (${angle.toFixed(0)}°). Aim for ${range.min}-${range.max}°`,
            severity: confidence < 0.4 ? 'critical' : 'warning',
            confidence,
          });
        }
      }
    });
  }

  // Analyze critical points
  if (rules.critical_points) {
    const criticalFeedback = analyzeCriticalPoints(
      exerciseName,
      keypoints,
      angles,
      rules.critical_points
    );
    feedback.push(...criticalFeedback);
  }

  // Detect motion quality (if we have previous angles)
  if (previousAngles) {
    const motionFeedback = analyzeMotion(
      exerciseName,
      angles,
      previousAngles
    );
    if (motionFeedback) {
      feedback.push(motionFeedback);
    }
  }

  const overallConfidence = totalAngles > 0 ? totalScore / totalAngles : 0;
  const isGoodForm =
    overallConfidence > 0.75 && feedback.filter((f) => f.severity === 'critical').length === 0;

  return {
    feedback,
    overallConfidence,
    bodyPartConfidence,
    isGoodForm,
  };
}

function calculateAngleConfidence(angle: number, min: number, max: number): number {
  const middle = (min + max) / 2;
  const range = (max - min) / 2;
  const distance = Math.abs(angle - middle);

  return Math.max(0, 1 - distance / range);
}

function formatJointName(joint: string): string {
  return joint
    .split('_')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

function analyzeCriticalPoints(
  exerciseName: string,
  keypoints: Keypoint[],
  angles: JointAngles,
  points: string[]
): FormFeedback[] {
  const feedback: FormFeedback[] = [];

  points.forEach((point) => {
    switch (point) {
      case 'knee_alignment':
        {
          const leftKnee = keypoints[LANDMARKS.LEFT_KNEE];
          const rightKnee = keypoints[LANDMARKS.RIGHT_KNEE];
          const leftHip = keypoints[LANDMARKS.LEFT_HIP];
          const rightHip = keypoints[LANDMARKS.RIGHT_HIP];
          const leftAnkle = keypoints[LANDMARKS.LEFT_ANKLE];
          const rightAnkle = keypoints[LANDMARKS.RIGHT_ANKLE];

          if (
            leftKnee &&
            leftHip &&
            leftAnkle &&
            leftKnee.visibility > 0.5
          ) {
            const leftAlignment = Math.abs(leftKnee.x - leftHip.x - (leftAnkle.x - leftHip.x) * 0.5);
            if (leftAlignment > 0.1) {
              feedback.push({
                bodyPart: 'Left Knee',
                issue: 'Knee caving inward. Keep knee aligned with ankle',
                severity: 'warning',
                confidence: 0.8,
              });
            }
          }
        }
        break;

      case 'back_straight':
        {
          const bodyTilt = angles.body_tilt || 0;
          if (Math.abs(bodyTilt) > 20) {
            feedback.push({
              bodyPart: 'Back',
              issue: 'Back is leaning too much. Keep torso upright',
              severity: 'warning',
              confidence: 0.8,
            });
          }
        }
        break;

      case 'weight_centered':
        {
          const leftHip = keypoints[LANDMARKS.LEFT_HIP];
          const rightHip = keypoints[LANDMARKS.RIGHT_HIP];
          const leftAnkle = keypoints[LANDMARKS.LEFT_ANKLE];
          const rightAnkle = keypoints[LANDMARKS.RIGHT_ANKLE];

          if (leftHip && rightHip && leftAnkle && rightAnkle) {
            const hipCenter = (leftHip.x + rightHip.x) / 2;
            const ankleCenter = (leftAnkle.x + rightAnkle.x) / 2;
            const imbalance = Math.abs(hipCenter - ankleCenter);

            if (imbalance > 0.1) {
              feedback.push({
                bodyPart: 'Weight Distribution',
                issue: 'Weight is shifted. Center weight between your feet',
                severity: 'info',
                confidence: 0.7,
              });
            }
          }
        }
        break;

      case 'body_straight':
        {
          const bodyTilt = angles.body_tilt || 0;
          if (Math.abs(bodyTilt) > 10) {
            feedback.push({
              bodyPart: 'Body Position',
              issue: 'Body is tilted. Keep your body in a straight line',
              severity: 'warning',
              confidence: 0.8,
            });
          }
        }
        break;

      case 'elbows_tracking':
        {
          const leftElbow = keypoints[LANDMARKS.LEFT_ELBOW];
          const rightElbow = keypoints[LANDMARKS.RIGHT_ELBOW];
          const leftShoulder = keypoints[LANDMARKS.LEFT_SHOULDER];
          const rightShoulder = keypoints[LANDMARKS.RIGHT_SHOULDER];

          if (leftElbow && leftShoulder && leftElbow.visibility > 0.5) {
            const leftTracking = Math.abs(leftElbow.x - leftShoulder.x);
            if (leftTracking > 0.15) {
              feedback.push({
                bodyPart: 'Elbows',
                issue: 'Elbows are flaring out. Keep them closer to body',
                severity: 'info',
                confidence: 0.7,
              });
            }
          }
        }
        break;

      case 'shoulders_engaged':
        {
          const leftShoulder = keypoints[LANDMARKS.LEFT_SHOULDER];
          const rightShoulder = keypoints[LANDMARKS.RIGHT_SHOULDER];

          if (leftShoulder && rightShoulder && leftShoulder.visibility > 0.5) {
            const shoulderDrop = leftShoulder.y + rightShoulder.y;
            // If shoulders are too high (low y value), they might not be engaged
            if (shoulderDrop < 0.3) {
              feedback.push({
                bodyPart: 'Shoulders',
                issue: 'Shoulders look disengaged. Activate your shoulders',
                severity: 'info',
                confidence: 0.6,
              });
            }
          }
        }
        break;

      case 'neutral_neck':
        {
          const nose = keypoints[LANDMARKS.NOSE];
          const leftShoulder = keypoints[LANDMARKS.LEFT_SHOULDER];
          const rightShoulder = keypoints[LANDMARKS.RIGHT_SHOULDER];

          if (nose && leftShoulder && rightShoulder && nose.visibility > 0.5) {
            const neckTilt = Math.abs(nose.x - (leftShoulder.x + rightShoulder.x) / 2);
            if (neckTilt > 0.15) {
              feedback.push({
                bodyPart: 'Neck',
                issue: 'Keep your neck neutral. Don\'t tilt your head',
                severity: 'info',
                confidence: 0.7,
              });
            }
          }
        }
        break;

      case 'front_knee_aligned':
        {
          const frontKnee = keypoints[LANDMARKS.LEFT_KNEE]; // Assuming left is front
          const frontHip = keypoints[LANDMARKS.LEFT_HIP];
          const frontAnkle = keypoints[LANDMARKS.LEFT_ANKLE];

          if (frontKnee && frontHip && frontAnkle && frontKnee.visibility > 0.5) {
            const alignment = Math.abs(frontKnee.x - frontHip.x - (frontAnkle.x - frontHip.x) * 0.5);
            if (alignment > 0.1) {
              feedback.push({
                bodyPart: 'Front Knee',
                issue: 'Front knee should stay over ankle. Adjust stance',
                severity: 'warning',
                confidence: 0.8,
              });
            }
          }
        }
        break;

      case 'back_knee_low':
        {
          const backKnee = keypoints[LANDMARKS.RIGHT_KNEE]; // Assuming right is back
          const backHip = keypoints[LANDMARKS.RIGHT_HIP];

          if (backKnee && backHip && backKnee.visibility > 0.5) {
            const lowness = backHip.y - backKnee.y;
            if (lowness < 0.1) {
              feedback.push({
                bodyPart: 'Back Knee',
                issue: 'Lower your back knee more. Get a deeper lunge',
                severity: 'info',
                confidence: 0.7,
              });
            }
          }
        }
        break;

      case 'upright_torso':
        {
          const bodyTilt = angles.body_tilt || 0;
          if (Math.abs(bodyTilt) > 15) {
            feedback.push({
              bodyPart: 'Torso',
              issue: 'Keep your torso upright. Don\'t lean too far forward',
              severity: 'warning',
              confidence: 0.8,
            });
          }
        }
        break;

      case 'engaged_core':
        {
          // Core engagement is hard to measure, but we can look at body alignment
          const bodyTilt = angles.body_tilt || 0;
          if (Math.abs(bodyTilt) > 5) {
            feedback.push({
              bodyPart: 'Core',
              issue: 'Engage your core. Keep body perfectly straight',
              severity: 'info',
              confidence: 0.6,
            });
          }
        }
        break;

      case 'straight_body':
        {
          const bodyTilt = angles.body_tilt || 0;
          if (Math.abs(bodyTilt) > 10) {
            feedback.push({
              bodyPart: 'Body',
              issue: 'Keep body in straight line from head to heels',
              severity: 'warning',
              confidence: 0.8,
            });
          }
        }
        break;
    }
  });

  return feedback;
}

function analyzeMotion(
  exerciseName: string,
  currentAngles: JointAngles,
  previousAngles: JointAngles
): FormFeedback | null {
  // Detect jerky movements
  const criticalJoints =
    exerciseName === 'Squat'
      ? ['left_knee', 'right_knee']
      : exerciseName === 'Push-up'
        ? ['left_elbow', 'right_elbow']
        : [];

  for (const joint of criticalJoints) {
    const angleDiff = Math.abs(
      (currentAngles[joint] || 0) - (previousAngles[joint] || 0)
    );

    // If angle change is too large in one frame, it might be jerky movement
    if (angleDiff > 30) {
      return {
        bodyPart: formatJointName(joint),
        issue: 'Movement is jerky. Focus on smooth, controlled motion',
        severity: 'info',
        confidence: 0.6,
      };
    }
  }

  return null;
}

export function filterFeedbackByFrequency(
  feedback: FormFeedback[],
  minConfidence: number = 0.6
): FormFeedback[] {
  return feedback
    .filter((f) => f.confidence >= minConfidence)
    .reduce((acc, current) => {
      const existingIndex = acc.findIndex(
        (f) =>
          f.bodyPart === current.bodyPart &&
          f.issue === current.issue
      );

      if (existingIndex === -1) {
        acc.push(current);
      } else {
        acc[existingIndex].confidence = Math.max(
          acc[existingIndex].confidence,
          current.confidence
        );
      }

      return acc;
    }, [] as FormFeedback[]);
}
