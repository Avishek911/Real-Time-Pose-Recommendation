import {
  PoseLandmarker,
  FilesetResolver,
  DrawingUtils,
} from '@mediapipe/tasks-vision';

export interface Keypoint {
  x: number;
  y: number;
  z: number;
  visibility: number;
}

export interface PoseData {
  keypoints: Keypoint[];
  confidence: number;
  timestamp: number;
}

export interface JointAngles {
  [key: string]: number;
}

export interface FormFeedback {
  bodyPart: string;
  issue: string;
  severity: 'info' | 'warning' | 'critical';
  confidence: number;
}

// MediaPipe Pose landmark indices
export const LANDMARKS = {
  NOSE: 0,
  LEFT_EYE: 1,
  RIGHT_EYE: 2,
  LEFT_EAR: 3,
  RIGHT_EAR: 4,
  LEFT_SHOULDER: 11,
  RIGHT_SHOULDER: 12,
  LEFT_ELBOW: 13,
  RIGHT_ELBOW: 14,
  LEFT_WRIST: 15,
  RIGHT_WRIST: 16,
  LEFT_HIP: 23,
  RIGHT_HIP: 24,
  LEFT_KNEE: 25,
  RIGHT_KNEE: 26,
  LEFT_ANKLE: 27,
  RIGHT_ANKLE: 28,
};

let poseLandmarker: PoseLandmarker | null = null;
let isInitialized = false;

export async function initializePoseDetector(): Promise<void> {
  if (isInitialized) return;

  try {
    const vision = await FilesetResolver.forVisionTasks(
      'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm'
    );

    poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath:
          'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task',
      },
      runningMode: 'VIDEO',
      numPoses: 1,
    });

    isInitialized = true;
    console.log('[v0] Pose detector initialized');
  } catch (error) {
    console.error('[v0] Failed to initialize pose detector:', error);
    throw error;
  }
}

export function detectPose(
  video: HTMLVideoElement | HTMLCanvasElement,
  timestamp: number
): PoseData | null {
  if (!poseLandmarker) {
    console.warn('[v0] Pose detector not initialized');
    return null;
  }

  try {
    const results = poseLandmarker.detectForVideo(video, timestamp);

    if (!results.landmarks || results.landmarks.length === 0) {
      return null;
    }

    const landmarks = results.landmarks[0];
    const keypoints: Keypoint[] = landmarks.map((landmark: any) => ({
      x: landmark.x,
      y: landmark.y,
      z: landmark.z,
      visibility: landmark.visibility || 0,
    }));

    // Calculate overall confidence as average of all visible keypoints
    const visibleKeypoints = keypoints.filter((kp) => kp.visibility > 0.5);
    const confidence =
      visibleKeypoints.length > 0
        ? visibleKeypoints.reduce((sum, kp) => sum + kp.visibility, 0) /
          visibleKeypoints.length
        : 0;

    return {
      keypoints,
      confidence,
      timestamp,
    };
  } catch (error) {
    console.error('[v0] Pose detection error:', error);
    return null;
  }
}

export function calculateAngle(
  pointA: Keypoint,
  pointB: Keypoint,
  pointC: Keypoint
): number {
  const radians =
    Math.atan2(pointC.y - pointB.y, pointC.x - pointB.x) -
    Math.atan2(pointA.y - pointB.y, pointA.x - pointB.x);
  let angle = Math.abs((radians * 180.0) / Math.PI);

  if (angle > 180.0) {
    angle = 360 - angle;
  }

  return angle;
}

export function calculateJointAngles(keypoints: Keypoint[]): JointAngles {
  const angles: JointAngles = {};

  try {
    // Elbow angles
    angles.left_elbow = calculateAngle(
      keypoints[LANDMARKS.LEFT_SHOULDER],
      keypoints[LANDMARKS.LEFT_ELBOW],
      keypoints[LANDMARKS.LEFT_WRIST]
    );

    angles.right_elbow = calculateAngle(
      keypoints[LANDMARKS.RIGHT_SHOULDER],
      keypoints[LANDMARKS.RIGHT_ELBOW],
      keypoints[LANDMARKS.RIGHT_WRIST]
    );

    // Knee angles
    angles.left_knee = calculateAngle(
      keypoints[LANDMARKS.LEFT_HIP],
      keypoints[LANDMARKS.LEFT_KNEE],
      keypoints[LANDMARKS.LEFT_ANKLE]
    );

    angles.right_knee = calculateAngle(
      keypoints[LANDMARKS.RIGHT_HIP],
      keypoints[LANDMARKS.RIGHT_KNEE],
      keypoints[LANDMARKS.RIGHT_ANKLE]
    );

    // Hip angles
    angles.left_hip = calculateAngle(
      keypoints[LANDMARKS.LEFT_SHOULDER],
      keypoints[LANDMARKS.LEFT_HIP],
      keypoints[LANDMARKS.LEFT_KNEE]
    );

    angles.right_hip = calculateAngle(
      keypoints[LANDMARKS.RIGHT_SHOULDER],
      keypoints[LANDMARKS.RIGHT_HIP],
      keypoints[LANDMARKS.RIGHT_KNEE]
    );

    // Shoulder angles
    angles.left_shoulder = calculateAngle(
      keypoints[LANDMARKS.LEFT_EAR],
      keypoints[LANDMARKS.LEFT_SHOULDER],
      keypoints[LANDMARKS.LEFT_ELBOW]
    );

    angles.right_shoulder = calculateAngle(
      keypoints[LANDMARKS.RIGHT_EAR],
      keypoints[LANDMARKS.RIGHT_SHOULDER],
      keypoints[LANDMARKS.RIGHT_ELBOW]
    );

    // Body angle (relative to vertical)
    const dx = keypoints[LANDMARKS.RIGHT_SHOULDER].x - keypoints[LANDMARKS.LEFT_SHOULDER].x;
    const dy = keypoints[LANDMARKS.RIGHT_SHOULDER].y - keypoints[LANDMARKS.LEFT_SHOULDER].y;
    angles.body_tilt = Math.atan2(dy, dx) * (180 / Math.PI);
  } catch (error) {
    console.error('[v0] Error calculating angles:', error);
  }

  return angles;
}

export function drawPose(
  canvas: HTMLCanvasElement,
  poseData: PoseData,
  formFeedback?: FormFeedback[],
  confidence?: number
): void {
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const keypoints = poseData.keypoints;

  // Draw keypoints
  keypoints.forEach((keypoint, index) => {
    if (keypoint.visibility < 0.5) return;

    const x = keypoint.x * canvas.width;
    const y = keypoint.y * canvas.height;

    // Color based on visibility
    const hue = Math.min(keypoint.visibility * 360, 120); // Green when confident
    ctx.fillStyle = `hsl(${hue}, 100%, 50%)`;

    ctx.beginPath();
    ctx.arc(x, y, 6, 0, 2 * Math.PI);
    ctx.fill();
  });

  // Draw connections (skeleton)
  const connections = [
    [LANDMARKS.LEFT_SHOULDER, LANDMARKS.LEFT_ELBOW],
    [LANDMARKS.LEFT_ELBOW, LANDMARKS.LEFT_WRIST],
    [LANDMARKS.RIGHT_SHOULDER, LANDMARKS.RIGHT_ELBOW],
    [LANDMARKS.RIGHT_ELBOW, LANDMARKS.RIGHT_WRIST],
    [LANDMARKS.LEFT_HIP, LANDMARKS.LEFT_KNEE],
    [LANDMARKS.LEFT_KNEE, LANDMARKS.LEFT_ANKLE],
    [LANDMARKS.RIGHT_HIP, LANDMARKS.RIGHT_KNEE],
    [LANDMARKS.RIGHT_KNEE, LANDMARKS.RIGHT_ANKLE],
    [LANDMARKS.LEFT_SHOULDER, LANDMARKS.LEFT_HIP],
    [LANDMARKS.RIGHT_SHOULDER, LANDMARKS.RIGHT_HIP],
    [LANDMARKS.LEFT_SHOULDER, LANDMARKS.RIGHT_SHOULDER],
    [LANDMARKS.LEFT_HIP, LANDMARKS.RIGHT_HIP],
  ];

  connections.forEach(([start, end]) => {
    const startKp = keypoints[start];
    const endKp = keypoints[end];

    if (startKp.visibility < 0.5 || endKp.visibility < 0.5) return;

    ctx.strokeStyle = 'rgba(0, 255, 0, 0.5)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(startKp.x * canvas.width, startKp.y * canvas.height);
    ctx.lineTo(endKp.x * canvas.width, endKp.y * canvas.height);
    ctx.stroke();
  });

  // Draw confidence overlay
  if (confidence !== undefined) {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(0, 0, canvas.width, 40);

    ctx.fillStyle = '#00ff00';
    ctx.font = 'bold 18px Arial';
    ctx.fillText(`Confidence: ${(confidence * 100).toFixed(0)}%`, 10, 25);
  }
}

export function getPoseLandmarkerInstance(): PoseLandmarker | null {
  return poseLandmarker;
}
