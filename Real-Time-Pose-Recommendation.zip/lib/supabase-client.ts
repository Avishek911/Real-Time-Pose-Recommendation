import { createClient } from '@supabase/supabase-js';

let supabase: ReturnType<typeof createClient> | null = null;

export function getSupabaseClient() {
  if (!supabase) {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Missing Supabase credentials');
    }

    supabase = createClient(supabaseUrl, supabaseKey);
  }
  return supabase;
}

export async function createExerciseSession(
  exerciseId: string,
  userId: string | null = null
) {
  try {
    const client = getSupabaseClient();
    const { data, error } = await client
      .from('exercise_sessions')
      .insert([
        {
          exercise_id: exerciseId,
          user_id: userId,
          started_at: new Date(),
        },
      ])
      .select();

    if (error) throw error;
    return data?.[0];
  } catch (error) {
    console.error('[v0] Failed to create session:', error);
    throw error;
  }
}

export async function savePoseFrame(
  sessionId: string,
  frameNumber: number,
  keypoints: any,
  jointAngles: any,
  formFeedback: any,
  formConfidence: number,
  bodyPartConfidence: any
) {
  try {
    const client = getSupabaseClient();
    const { error } = await client.from('pose_frames').insert([
      {
        session_id: sessionId,
        frame_number: frameNumber,
        timestamp: new Date(),
        keypoints,
        joint_angles: jointAngles,
        form_feedback: formFeedback,
        form_confidence: formConfidence,
        body_part_confidence: bodyPartConfidence,
      },
    ]);

    if (error) throw error;
  } catch (error) {
    console.error('[v0] Failed to save frame:', error);
  }
}

export async function updateSessionStats(
  sessionId: string,
  duration: number,
  averageConfidence: number
) {
  try {
    const client = getSupabaseClient();
    const { error } = await client
      .from('exercise_sessions')
      .update({
        ended_at: new Date(),
        duration_seconds: duration,
        average_form_confidence: averageConfidence,
      })
      .eq('id', sessionId);

    if (error) throw error;
  } catch (error) {
    console.error('[v0] Failed to update session:', error);
  }
}

export async function getExerciseById(exerciseId: string) {
  try {
    const client = getSupabaseClient();
    const { data, error } = await client
      .from('exercises')
      .select('*')
      .eq('id', exerciseId)
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('[v0] Failed to fetch exercise:', error);
    return null;
  }
}

export async function getAllExercises() {
  try {
    const client = getSupabaseClient();
    const { data, error } = await client
      .from('exercises')
      .select('*');

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('[v0] Failed to fetch exercises:', error);
    return [];
  }
}

export async function getUserSessions(userId: string) {
  try {
    const client = getSupabaseClient();
    const { data, error } = await client
      .from('exercise_sessions')
      .select('*, exercises(name)')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(20);

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('[v0] Failed to fetch sessions:', error);
    return [];
  }
}

export async function getSessionStatistics(userId: string, exerciseId: string) {
  try {
    const client = getSupabaseClient();
    const { data, error } = await client
      .from('session_statistics')
      .select('*')
      .eq('user_id', userId)
      .eq('exercise_id', exerciseId)
      .single();

    if (error && error.code === 'PGRST116') {
      // Not found, return null
      return null;
    }

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('[v0] Failed to fetch statistics:', error);
    return null;
  }
}
