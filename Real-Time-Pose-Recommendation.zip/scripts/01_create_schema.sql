-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255),
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Exercises table
CREATE TABLE IF NOT EXISTS exercises (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100),
  -- Joint angles for form analysis (stored as JSON)
  form_rules JSONB DEFAULT '{}',
  difficulty_level VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Exercise sessions table
CREATE TABLE IF NOT EXISTS exercise_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  exercise_id UUID NOT NULL REFERENCES exercises(id),
  started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ended_at TIMESTAMP,
  duration_seconds INTEGER,
  repetitions_completed INTEGER,
  average_form_confidence FLOAT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pose frames table (stores individual frame data)
CREATE TABLE IF NOT EXISTS pose_frames (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id UUID NOT NULL REFERENCES exercise_sessions(id) ON DELETE CASCADE,
  frame_number INTEGER NOT NULL,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  -- Pose keypoints stored as JSONB (33 MediaPipe joints with x, y, z, confidence)
  keypoints JSONB NOT NULL,
  -- Calculated angles for key joints
  joint_angles JSONB,
  -- Form feedback for this frame
  form_feedback JSONB,
  -- Overall form confidence for this frame (0-100)
  form_confidence FLOAT,
  -- Individual body part confidence scores
  body_part_confidence JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Form recommendations history table
CREATE TABLE IF NOT EXISTS form_recommendations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id UUID NOT NULL REFERENCES exercise_sessions(id) ON DELETE CASCADE,
  body_part VARCHAR(100),
  recommendation_type VARCHAR(100),
  message TEXT,
  severity VARCHAR(50), -- 'info', 'warning', 'critical'
  frame_number INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Session statistics table (aggregated analytics)
CREATE TABLE IF NOT EXISTS session_statistics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  exercise_id UUID NOT NULL REFERENCES exercises(id),
  total_sessions INTEGER DEFAULT 1,
  total_duration_seconds INTEGER DEFAULT 0,
  average_form_confidence FLOAT,
  most_common_form_issue VARCHAR(255),
  best_form_session_id UUID REFERENCES exercise_sessions(id),
  last_session_date TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, exercise_id)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON exercise_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_exercise_id ON exercise_sessions(exercise_id);
CREATE INDEX IF NOT EXISTS idx_pose_frames_session_id ON pose_frames(session_id);
CREATE INDEX IF NOT EXISTS idx_recommendations_session_id ON form_recommendations(session_id);
CREATE INDEX IF NOT EXISTS idx_statistics_user_id ON session_statistics(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_created ON exercise_sessions(created_at DESC);

-- Insert common exercises with form rules
INSERT INTO exercises (name, description, category, form_rules, difficulty_level) VALUES
(
  'Squat',
  'Lower body exercise targeting quads, glutes, and hamstrings',
  'Lower Body',
  '{
    "target_angles": {
      "left_knee": {"min": 60, "max": 110},
      "right_knee": {"min": 60, "max": 110},
      "left_hip": {"min": 70, "max": 100},
      "right_hip": {"min": 70, "max": 100},
      "back_angle": {"min": 15, "max": 45}
    },
    "critical_points": ["knee_alignment", "back_straight", "weight_centered"]
  }'::jsonb,
  'Beginner'
),
(
  'Push-up',
  'Upper body exercise targeting chest, shoulders, and triceps',
  'Upper Body',
  '{
    "target_angles": {
      "left_elbow": {"min": 45, "max": 90},
      "right_elbow": {"min": 45, "max": 90},
      "shoulder_angle": {"min": 60, "max": 90}
    },
    "critical_points": ["body_straight", "elbows_tracking", "shoulders_engaged"]
  }'::jsonb,
  'Beginner'
),
(
  'Lunge',
  'Lower body exercise for single leg strength and balance',
  'Lower Body',
  '{
    "target_angles": {
      "front_knee": {"min": 70, "max": 110},
      "back_knee": {"min": 30, "max": 90},
      "torso_angle": {"min": 10, "max": 30}
    },
    "critical_points": ["front_knee_aligned", "back_knee_low", "upright_torso"]
  }'::jsonb,
  'Intermediate'
),
(
  'Plank',
  'Core stability exercise',
  'Core',
  '{
    "target_angles": {
      "body_angle": {"min": 0, "max": 10}
    },
    "critical_points": ["straight_body", "engaged_core", "neutral_neck"]
  }'::jsonb,
  'Beginner'
);
