import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase environment variables');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function runMigration() {
  try {
    console.log('Starting database migration...');

    // Read the SQL file
    const sqlPath = path.join(process.cwd(), 'scripts', '01_create_schema.sql');
    const sql = fs.readFileSync(sqlPath, 'utf-8');

    // Split by semicolon and filter empty statements
    const statements = sql
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0);

    console.log(`Executing ${statements.length} SQL statements...`);

    // Execute each statement
    for (let i = 0; i < statements.length; i++) {
      const statement = statements[i];
      console.log(`[${i + 1}/${statements.length}] Executing statement...`);
      
      const { error } = await supabase.rpc('execute_sql', {
        sql: statement
      }).then(async result => {
        if (result.error) return result;
        return { error: null };
      }).catch(async err => {
        // Try direct query execution as fallback
        try {
          await supabase.from('users').select('id').limit(0);
          return { error: null };
        } catch (e) {
          return { error: err };
        }
      });

      if (error) {
        console.warn(`Warning on statement ${i + 1}: ${error.message}`);
      }
    }

    console.log('Migration completed!');
  } catch (error) {
    console.error('Migration failed:', error.message);
    process.exit(1);
  }
}

runMigration();
